import random

class Bank:
    def __init__(self,name,email):
        self.name = name
        self.email = email
        self.__acc_no = random.randint(1,100000000)
        self.__pin = random.randint(1,9999)
        self.__balance = 0

    # def getAccountNum(self):
    #     return self.__acc_no
    #
    # def getPin(self):
    #     return self.__pin
    #
    # def getBalance(self):
    #     return self.__balance

    @property
    def acc_no(self):
        print(" Acc No Getter Called for", self.name)
        return self.__acc_no

    @acc_no.setter
    def acc_no(self, value):
        self.__acc_no = value
        print("Setter called and acc_no is set")

    @property
    def bal(self):
        print("Bal Getter Called for", self.name)
        return self.__balance

    @bal.setter
    def bal(self, value):
        self.__balance = value
        print("Setter called and bal is set")

    @property
    def pin(self):
        print("Pin Getter Called for", self.name)
        return self.__pin

    @pin.setter
    def pin(self, value):
        self.__pin = value
        print("Setter called and pin is set")

    def __str__(self):
        return self.name

users = []
def createAccount(name,email):
    obj = Bank(name,email)
    obj.acc_no = random.randint(1, 100000000)
    obj.pin = random.randint(1, 9999)
    obj.bal = 0
    users.append(obj)
    return obj


def enquiry(email,pin):
    for i in range(len(users)):
        # print(users[i].email, users[i].getPin())
        if users[i].email == email and users[i].pin == pin:
            return users[i]
    else:
        return "Invalid Details, User Not Found"