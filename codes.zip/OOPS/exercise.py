# Build a class Bank
# Print a menu when user enters into the bank class
# 1. Create Account 2. Balance Enquiry 3. Withdraw 4. Deposit 5. Check Loan Avail
# build a method for each of the operation
# perform specific task inside that method

class Bank:
    def __init__(self, name, email, password):
        pass
        # self.name
        # self.email
        # self.password
        # self.account_num
        # self.pin
    def showMenu(self):
        print("""
        1. Create Account
        2. Balance Enquiry
        """)

    def createAccount(self):
        pass

    def balEnquiry(self):
        pass

    def withdraw(self):
        pass

    def deposit(self):
        pass

    def checkLoan(self):
        pass