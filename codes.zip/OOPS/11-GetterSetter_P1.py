import random

class Bank:
    def __init__(self,name,email):
        self.name = name
        self.email = email
        self.__balance = 0

    def setAccountNum(self):
        self.__acc_no = random.randint(1,100000000)

    def getAccountNum(self):
        return self.__acc_no

    def setPin(self):
        self.__pin = random.randint(1, 9999)

    def getPin(self):
        return self.__pin

    def __str__(self):
        return self.name


obj = Bank('Ram', 'ram@gmail.com')
obj.setAccountNum()
print(obj.getAccountNum())