import random

class Bank:
    def __init__(self, name, email):
        self.name = name
        self.email = email
        self.__balance = 0
        self.__acc_no = None
        self.__pin = None

    @property
    def acc_no(self):
        print("Getter Called for",self.name)
        return self.__acc_no

    @acc_no.setter
    def acc_no(self,value):
        self.__acc_no = value
        print("Setter called and acc_no is set")

    @property
    def bal(self):
        print("Getter Called for", self.name)
        return self.__balance

    @bal.setter
    def bal(self, value):
        self.__balance = value
        print("Setter called and acc_no is set")

    @property
    def pin(self):
        print("Getter Called for", self.name)
        return self.__pin

    @pin.setter
    def pin(self, value):
        self.__pin = value
        print("Setter called and acc_no is set")

    def __str__(self):
        return self.name

obj = Bank('Ram', 'ram@gmail.com')
# print(obj.acc_no)
obj.acc_no = random.randint(1000,100000)
print(obj.acc_no)