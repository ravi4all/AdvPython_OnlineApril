import random

class Bank:
    def __init__(self, name, email):
        self.name = name
        self.email = email
        self.__balance = 0

    def __set__(self, instance, value):
        print("Setter Called...")
        self.__acc_no = value

    def __get__(self, instance, owner):
        print("Getter Called...")
        return self.__acc_no

    def __str__(self):
        return self.name

class User:
    bank = Bank('Ram', 'ram@gmail.com')

obj = User()
obj.bank = 1212212
print(obj.bank)