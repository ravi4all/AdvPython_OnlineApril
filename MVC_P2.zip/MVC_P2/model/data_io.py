import csv

def readUsers():
    data = []
    with open('customers.csv','r') as file:
        reader = csv.reader(file)
        for row in reader:
            data.append(row)
    return data

def writeUser(obj):
    with open('customers.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([obj.name,obj.email,obj.acc_no,obj.pin,obj.bal])

def withdraw():
    pass

def deposit():
    pass