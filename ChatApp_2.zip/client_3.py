from PyQt5 import QtCore, QtGui, QtWidgets
import json, threading, readWriteClient
import socket

class Ui_MainWindow(object):
    chatData = readWriteClient.readUsers()

    s = socket.socket()
    ip = '127.0.0.1'
    port = 80
    s.connect((ip, port))

    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1187, 790)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.listWidget = QtWidgets.QListWidget(self.centralwidget)
        self.listWidget.setGeometry(QtCore.QRect(10, 10, 401, 711))
        self.listWidget.setStyleSheet("font: 14pt \"MS Shell Dlg 2\";")
        self.listWidget.setObjectName("listWidget")
        self.listWidget_2 = QtWidgets.QListWidget(self.centralwidget)
        self.listWidget_2.setGeometry(QtCore.QRect(420, 10, 751, 461))
        self.listWidget_2.setStyleSheet("font: 14pt \"MS Shell Dlg 2\";")
        self.listWidget_2.setObjectName("listWidget_2")
        self.textEdit = QtWidgets.QTextEdit(self.centralwidget)
        self.textEdit.setGeometry(QtCore.QRect(420, 490, 751, 141))
        self.textEdit.setObjectName("textEdit")
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(420, 660, 201, 61))
        self.pushButton.setStyleSheet("font: 18pt \"MS Shell Dlg 2\";")
        self.pushButton.setObjectName("pushButton")
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_2.setGeometry(QtCore.QRect(670, 660, 201, 61))
        self.pushButton_2.setStyleSheet("font: 18pt \"MS Shell Dlg 2\";")
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_3 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_3.setGeometry(QtCore.QRect(910, 660, 261, 61))
        self.pushButton_3.setStyleSheet("font: 18pt \"MS Shell Dlg 2\";")
        self.pushButton_3.setObjectName("pushButton_3")
        self.frame = QtWidgets.QFrame(self.centralwidget)
        self.frame.setGeometry(QtCore.QRect(0, 0, 1181, 741))
        self.frame.setStyleSheet("background-color: rgb(255, 255, 255);")
        self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame.setObjectName("frame")
        self.label = QtWidgets.QLabel(self.frame)
        self.label.setGeometry(QtCore.QRect(440, 20, 321, 61))
        self.label.setStyleSheet("font: 18pt \"MS Shell Dlg 2\";")
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.frame)
        self.label_2.setGeometry(QtCore.QRect(80, 170, 411, 51))
        self.label_2.setStyleSheet("font: 20pt \"MS Shell Dlg 2\";")
        self.label_2.setObjectName("label_2")
        self.lineEdit = QtWidgets.QLineEdit(self.frame)
        self.lineEdit.setGeometry(QtCore.QRect(550, 160, 481, 71))
        self.lineEdit.setObjectName("lineEdit")
        self.pushButton_4 = QtWidgets.QPushButton(self.frame)
        self.pushButton_4.setGeometry(QtCore.QRect(330, 430, 471, 81))
        self.pushButton_4.setStyleSheet("font: 22pt \"MS Shell Dlg 2\";")
        self.pushButton_4.setObjectName("pushButton_4")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1187, 31))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.textEdit.setHtml(_translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>"))
        self.pushButton.setText(_translate("MainWindow", "Send"))
        self.pushButton_2.setText(_translate("MainWindow", "Attach File"))
        self.pushButton_3.setText(_translate("MainWindow", "Voice Message"))
        self.label.setText(_translate("MainWindow", "Start Conversation"))
        self.label_2.setText(_translate("MainWindow", "Enter Your UserName"))
        self.pushButton_4.setText(_translate("MainWindow", "Start Chat"))

        self.pushButton_4.clicked.connect(self.startChat)
        self.listWidget.itemClicked.connect(self.changeUser)
        self.pushButton.clicked.connect(self.sendMessage)

    def startChat(self):
        try:
            self.frame.hide()
            self.showUsers()
            threading.Thread(target=self.checkMsg).start()
        except BaseException as ex:
            print(ex)

    def showUsers(self):
        self.listWidget.clear()
        self.users = list(self.chatData.keys())
        n = len(self.users)
        for i in range(n):
            item = QtWidgets.QListWidgetItem()
            self.listWidget.addItem(item)
            item.setText(self.users[i])

    def changeUser(self, item):
        self.current_user = item.text()
        self.showConversation(self.current_user)

    def showConversation(self, current_user):
        self.listWidget_2.clear()
        try:
            chat = self.chatData[current_user]
            for data in chat:
                for key in data:
                    item = QtWidgets.QListWidgetItem()
                    self.listWidget_2.addItem(item)
                    if key == 'msg':
                        item.setText(data[key])
                        item.setTextAlignment(QtCore.Qt.AlignLeft)
                    else:
                        item.setText(data[key])
                        item.setTextAlignment(QtCore.Qt.AlignRight)
        except BaseException as ex:
            print(ex)

    def sendMessage(self):
        try:
            msg = self.textEdit.toPlainText()
            item = QtWidgets.QListWidgetItem()
            self.listWidget_2.addItem(item)
            item.setText(msg)
            item.setTextAlignment(QtCore.Qt.AlignRight)
            self.textEdit.setText("")
            chat = self.chatData[self.current_user]
            chat.append({'rply': msg})
            readWriteClient.writeChat(self.chatData)

            msg = {"msg": msg, "user": self.lineEdit.text()}
            msg = json.dumps(msg)
            self.s.send(msg.encode())
        except BaseException as ex:
            print(ex)

    def checkMsg(self):
        while True:
            recv_msg = self.s.recv(10000).decode()
            # print("Client : ", recv_msg)
            recv_msg = json.loads(recv_msg)
            self.currentUser = recv_msg['user']
            msg = recv_msg['msg']
            self.users = list(self.chatData.keys())
            if msg != "":
                for i in range(len(self.users)):
                    print(self.users[i])
                    if self.users[i] == self.currentUser:
                        print("User already exist")
                        conv = {'msg': msg}
                        self.chatData[self.currentUser].append(conv)
                        readWriteClient.writeChat(self.chatData)
                        self.showConversation(self.currentUser)
                        break
                else:
                    print("I will create new user")
                    readWriteClient.createNewUser(self.currentUser)
                    self.chatData = readWriteClient.readUsers()
                    self.showUsers()
                    conv = {'msg': msg}
                    self.chatData[self.currentUser].append(conv)
                    readWriteClient.writeChat(self.chatData)
                    self.showConversation(self.currentUser)


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
