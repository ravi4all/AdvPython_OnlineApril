import json

def readUsers():
    file = open('serverChat.json')
    data = json.load(file)
    file.close()
    return data

def writeChat(data):
    file = open('serverChat.json','w')
    json.dump(data,file)
    file.close()

def createNewUser(user):
    data = readUsers()
    data[user] = []
    writeChat(data)
