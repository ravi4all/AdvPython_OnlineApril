import pymysql
import config

connection = pymysql.connect(host = config.host, port = config.port, database = config.database,
                             user = config.user, autocommit = True)
cursor = connection.cursor()

def storeUser(obj):
    if obj.role == "teacher":
        table = "teachers"
    else:
        table = "students"
    query = "insert into {} (name,id,pwd,grade) values (%s, %s, %s, %s)".format(table)
    cursor.execute(query, (obj.name, obj.id, obj.pwd, obj.grade))