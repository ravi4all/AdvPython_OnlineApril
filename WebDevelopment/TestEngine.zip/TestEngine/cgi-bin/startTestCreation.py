import cgi

form = cgi.FieldStorage()

id = form.getvalue('id')
sub = form.getvalue('sub')
grade = form.getvalue('grade')

