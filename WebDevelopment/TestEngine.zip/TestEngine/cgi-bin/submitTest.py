import cgi
import model

form = cgi.FieldStorage()

test_id = form.getvalue('test_id')
num_ques = form.getvalue('num_ques')
answers = []
attempted = 0
unattempted = 0
for i in range(int(num_ques)):
    ans = form.getvalue('ques_{}'.format(i+1))
    if ans:
        answers.append(str(ans).replace('+',' '))
        attempted += 1
    else: unattempted += 1

# calculate marks

# submit marks in results table



print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

    <h1>Test Submitted</h1>
    <hr>
    <h2>Number of questions : {}</h2>
    <h4>Attempted : {}</h4>
    <h4>Unattempted : {}</h4>
      """.format(num_ques, attempted, unattempted))

print("""
</body>
</html>
""")