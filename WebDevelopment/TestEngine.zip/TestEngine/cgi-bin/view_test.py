import cgi
import model

form = cgi.FieldStorage()

t_id = form.getvalue('t_id')

questions = model.fetchQuestions(t_id)

print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

    <h1>Test</h1>
    <hr>
""".format(id))

print("<div>")

for i in range(len(questions)):
    print("""
        <h4> {} </h4>
        <ul>
            <li> Option 1 : {} </li>
            <li> Option 2 : {} </li>
            <li> Option 3 :{} </li>
            <li> Option 4 :{} </li>
            <li> Answer : {} </li>
        </ul>
    """.format(questions[i][1], questions[i][2], questions[i][3], questions[i][4],
               questions[i][5], questions[i][6]))

print("</div>")

print("""
</body>
</html>
""")