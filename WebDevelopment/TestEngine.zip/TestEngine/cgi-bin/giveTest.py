import cgi
import model

form = cgi.FieldStorage()

id = form.getvalue('id')
grade = form.getvalue('grade')
subjects = model.getSubjects(grade)

print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

    <h1>Start Test</h1>
    <hr>
    <form action='showTest.py'>
        <input type='hidden' value={} name='grade'>
        <table>
            <tr>
                <td>Choose Subject</td>
                <td>
                    <select name='sub'>
                        <option>Choose Subject</option>""".format(grade))


for i in range(len(subjects)):
    print("""
    <option value={}>{}</option>
    """.format(subjects[i][0],subjects[i][0]))

print("""
                    </select>
                </td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <input type='submit'>
                </td>
            </tr>
        </table>
    </form>
""".format(id))
# print("<h3>Subjects {}</h3>".format(subjects))

print("""
</body>
</html>
""")