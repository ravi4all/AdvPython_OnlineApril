import cgi
import model

form = cgi.FieldStorage()

test_id = form.getvalue('t_id')

questions = model.getQuestions(test_id)

print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

    <h1>Start Test</h1>
    <hr>
      """)

print("<form action='submitTest.py' method='post'> ")
print("""
<input type='hidden' value={} name='test_id'>
<input type='hidden' value={} name='num_ques'>
""".format(test_id, len(questions)))
opt_id = 0
for i in range(len(questions)):
    print("""
        <h4> {} </h4>
        <ul style='list-style:none;'>""".format(questions[i][1]))

    for j in range(2,len(questions[i]) - 2):
        opt_id += 1
        print("""
            <li> 
                <input type = 'radio' value={} name = 'ques_{}' id = '{}'>
                <label for = '{}'> {} </label>
            </li>
        """.format(questions[i][j].replace(' ','+'),i+1,opt_id,opt_id, questions[i][j]))

    print("</ul>")

print("""
<input type='submit'>
</form>
""")

print("""
</body>
</html>
""")