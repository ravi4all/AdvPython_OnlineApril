import cgi
import model

form = cgi.FieldStorage()

id = form.getvalue('id')

if form.getvalue('test'):
    form_state = True
    subject = form.getvalue('sub')
    grade = form.getvalue('grade')
    model.insertTest(id, subject, grade)
else:
    form_state = False

if form.getvalue('test_id'):
    test_id = form.getvalue('test_id')
    ques = form.getvalue('ques')
    opt_1 = form.getvalue('opt_1')
    opt_2 = form.getvalue('opt_2')
    opt_3 = form.getvalue('opt_3')
    opt_4 = form.getvalue('opt_4')
    ans = form.getvalue('ans')
    model.insertQues(test_id,ques,opt_1,opt_2,opt_3,opt_4,ans)

test = model.getTest(id)

print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

    <h1>Create Test</h1>
""")

if not form_state:
    print("""
    <form action='createTest.py'>
        <input type='hidden' value={} name='id'>
        <input type='hidden' value='create' name='test'>
        <table>
            <tr>
                <td>Choose Subject</td>
                <td>
                    <select name='sub'>
                        <option>Choose Subject</option>
                        <option value='Computer Science'>Computers</option>
                        <option value='math'>Math</option>
                        <option value='General Knowledge'>General Knowledge</option>
                        <option value='python'>Python</option>
                        <option value='science'>Science</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Choose Grade</td>
                <td>
                    <select name="grade">
                        <option>Select Grade</option>
                        <option value="7">7th</option>
                        <option value="8">8th</option>
                        <option value="9">9th</option>
                        <option value="10">10th</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <input type="submit" value='Insert Question'>
                </td>
            </tr>
        </table>
    </form>
    <hr>
""".format(id))

print("""
    <h2>Start Inserting Questions</h2>
    <form action='createTest.py'>
        <input type='hidden' value={} name='id'>
        <table cellpadding=10>
            <tr>
                <td>Enter Test ID</td>
                <td>
                    <select name='test_id'>
                    """)

for i in range(len(test)):
    print("""
    <option value = {}>{}</option>
    """.format(test[i][0], test[i][0]))

print("""
                    </select>
            </tr>
            <tr>
                <td>Enter Question</td>
                <td>
                    <textarea name = 'ques' rows = 5 cols = 50 placeholder = 'Enter question'>
                    </textarea>
                </td>
            </tr>
            <tr>
                <td>Enter Option 1</td>
                <td>
                    <input type = 'text' placeholder = 'Enter Option 1' name='opt_1'>
                </td>
            </tr>
            <tr>
                <td>Enter Option 2</td>
                <td>
                    <input type = 'text' placeholder = 'Enter Option 2' name='opt_2'>
                </td>
            </tr>
            <tr>
                <td>Enter Option 3</td>
                <td>
                    <input type = 'text' placeholder = 'Enter Option 3' name='opt_3'>
                </td>
            </tr>
            <tr>
                <td>Enter Option 4</td>
                <td>
                    <input type = 'text' placeholder = 'Enter Option 4' name='opt_4'>
                </td>
            </tr>
            <tr>
                <td>Enter Answer</td>
                <td>
                    <input type = 'text' placeholder = 'Enter Answer' name='ans'>
                </td>
            </tr>
            <tr>
                <td>
                    <input type = 'reset'>
                </td>
                <td>
                    <input type = 'submit'>
                </td>
            </tr>
        </table>
    </form>
""")


print("""
</body>
</html>
""")