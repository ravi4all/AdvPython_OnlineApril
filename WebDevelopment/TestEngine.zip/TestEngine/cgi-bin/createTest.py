import cgi

form = cgi.FieldStorage()

id = form.getvalue('id')

print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

    <h1>Create Test</h1>
    <form action='startTestCreation.py'>
        <input type='hidden' value={} name='id'>
        <table>
            <tr>
                <td>Choose Subject</td>
                <td>
                    <select name='sub'>
                        <option value='Computers'>Computers</option>
                        <option value='math'>Math</option>
                        <option value='science'>Science</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Choose Grade</td>
                <td>
                    <select name="grade">
                        <option>Select Grade</option>
                        <option value="7">7th</option>
                        <option value="8">8th</option>
                        <option value="9">9th</option>
                        <option value="10">10th</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <input type="submit" value='Create Test'>
                </td>
            </tr>
        </table>
    </form>
""".format(id))


print("""
</body>
</html>
""")