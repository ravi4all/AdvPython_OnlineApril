import data_io

class User:
    def __init__(self, role, name, id, pwd, grade):
        self.name = name
        self.role = role
        self.id = id
        self.pwd = pwd
        self.grade = grade

def registerUser(role, name, id, pwd, grade):
    obj = User(role, name, id, pwd, grade)
    data_io.storeUser(obj)

def loginUser(role, id, pwd):
    user = data_io.loginUser(role, id, pwd)
    return user

def fetchAllTest():
    data = data_io.fetchAllTest()
    return data

def fetchMyTest(id):
    data = data_io.fetchMyTest(id)
    return data

def fetchQuestions(id):
    data = data_io.fetchQuestions(id)
    return data