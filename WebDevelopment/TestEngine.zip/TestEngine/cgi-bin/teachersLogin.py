import cgi

form = cgi.FieldStorage()

id = form.getvalue('id')

print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

    <h1>Teacher's Dashboard</h1>
    <nav>
        <ul>
            <li> <a href='createTest.py?id={}'>Create Test</a> </li>
            <li> <a href='viewTest.py'>View Test</a> </li>
            <li> <a href='editTest.py'>Edit Test</a> </li>
            <li> <a href='deleteTest.py'>Delete Test</a> </li>
            <li> <a href='viewResults.py'>View Results</a> </li>
        </ul>
    </nav>
""".format(id))


print("""
</body>
</html>
""")