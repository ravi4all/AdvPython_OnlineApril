import pymysql
import config

connection = pymysql.connect(host = config.host, port = config.port, database = config.database,
                             user = config.user, autocommit = True)
cursor = connection.cursor()

def storeUser(obj):
    if obj.role == "teacher":
        table = "teachers"
    else:
        table = "students"
    query = "insert into {} (name,id,pwd,grade) values (%s, %s, %s, %s)".format(table)
    cursor.execute(query, (obj.name, obj.id, obj.pwd, obj.grade))

def loginUser(role,id,pwd):
    if role == "teacher":
        table = "teachers"
    else:
        table = "students"
    query = "select * from {} where id = %s and pwd = %s".format(table)
    cursor.execute(query, (id,pwd))
    data = cursor.fetchall()
    # data = (('ram',101,1223,'data'))
    return data

def fetchAllTest():
    query = "select * from test"
    cursor.execute(query)
    data = cursor.fetchall()
    return data

def fetchMyTest(id):
    query = "select * from test where teacher_id = %s"
    cursor.execute(query, id)
    data = cursor.fetchall()
    return data

def fetchQuestions(id):
    query = "select * from questions where test_id = %s"
    cursor.execute(query, int(id))
    data = cursor.fetchall()
    return data

def insertTest(id,sub,grade):
    query = "insert into test (teacher_id, subject, grade) values (%s, %s, %s)"
    cursor.execute(query, (id,sub, grade))

def getTest(id):
    query = "select * from test where teacher_id=%s"
    cursor.execute(query, id)
    data = cursor.fetchall()
    # data = (('ram',101),('shaym',102),('aman',103))
    # data[0][0]
    return data

def insertQues(test_id,ques,opt_1,opt_2,opt_3,opt_4,ans):
    query = "insert into questions (test_id, ques,opt_1,opt_2,opt_3,opt_4,ans_choice) values (%s,%s,%s,%s,%s,%s,%s)"
    cursor.execute(query,(int(test_id),ques,opt_1,opt_2,opt_3,opt_4,ans))

def getStudentData(id):
    query = "select * from students where id = %s"
    cursor.execute(query, id)
    data = cursor.fetchall()
    return data

def getSub(grade):
    query = "select subject from test where grade = %s"
    cursor.execute(query, grade)
    data = cursor.fetchall()
    return data

def getInfo(grade, sub):
    query = "select * from test where subject = %s and grade = %s"
    cursor.execute(query, (sub, grade))
    data = cursor.fetchall()
    return data

def getQues(id):
    query = "select * from questions where test_id = %s"
    cursor.execute(query, id)
    data = cursor.fetchall()
    return data
