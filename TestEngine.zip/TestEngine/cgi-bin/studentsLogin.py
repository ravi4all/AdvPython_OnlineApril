import cgi
import model

form = cgi.FieldStorage()

id = form.getvalue('id')
my_data = model.fetchStudentData(id)


print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

    <h1>Student's Dashboard</h1>
    <h4>Name : {}</h4>
    <h4>Grade : {}</h4>
    <nav>
        <ul>
            <li> <a href='giveTest.py?id={}&grade={}'>Give Test</a> </li>
            <li> <a href='viewTest.py'>View Test</a> </li>
            <li> <a href='viewResults.py'>View Results</a> </li>
        </ul>
    </nav>
    <hr>
""".format(my_data[0][0],my_data[0][3],id,my_data[0][3]))

print("""
<h2>Test given by you : </h2>
<table width='100%' border=2 cellpadding=10>
    <tr>
        <th>Test ID</th>
        <th>Subject</th>
        <th>Grade</th>
        <th>Visit Test</th>
""")

print("</table>")

print("""
</body>
</html>
""")