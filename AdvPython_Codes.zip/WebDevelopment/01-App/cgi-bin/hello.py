# python -m http.server --cgi
#!python_path
print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

    <h1>Hello World using Python Programming</h1>

</body>
</html>
""")