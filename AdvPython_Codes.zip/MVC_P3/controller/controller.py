import sys
sys.path.append('..')

from model import model

def createAcc(name,email):
    msg = model.createAccount(name,email)
    return msg

def balEnquiry(email,pin):
    res = model.enquiry(email,pin)
    return res

def authenticateUser(email,pin):
    auth,user = model.authenticate(email,pin)
    return auth,user

def withdraw(amount,user):
    msg = model.withdraw(amount,user)
    return msg