import sys
sys.path.append('..')

from controller import controller

def createAccount():
    name = input("Enter your name : ")
    email = input("Enter your email : ")
    user = controller.createAcc(name,email)
    print("Hello {}, Your Account Created Successfully".format(user))
    print("Your Account Number is",user.acc_no)
    print("Your PIN is",user.pin)
    print("Your current balance is",user.bal)

def balEnquiry():
    email = input("Enter your email : ")
    pin = input("Enter your PIN : ")
    msg = controller.balEnquiry(email,pin)
    print(msg)

def withdraw():
    email = input("Enter your email : ")
    pin = input("Enter your PIN : ")
    res,user = controller.authenticateUser(email,pin)
    if res == "valid":
        amount = int(input("Welcome {}, Enter the amount : ".format(user[0])))
        msg = controller.withdraw(amount,user)
        print(msg)
    else:
        print(res)

def menu():
    while True:
        print("""
        1. Create Account
        2. Balance Enquiry
        3. Withdraw
        4. Balance Transfer
        5. Deposit
        """)
        ch = input("Enter your choice : ")
        operations = {
            "1" : createAccount,
            "2" : balEnquiry,
            "3" : withdraw,
            # "4" : balTransfer,
            # "5" : deposit
        }
        operations.get(ch)()

menu()