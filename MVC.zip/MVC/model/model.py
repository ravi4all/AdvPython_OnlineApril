import random

class Bank:
    def __init__(self,name,email):
        self.name = name
        self.email = email
        self.__acc_no = random.randint(1,100000000)
        self.__pin = random.randint(1,9999)
        self.__balance = 0

    def getAccountNum(self):
        return self.__acc_no

    def getPin(self):
        return self.__pin

    def getBalance(self):
        return self.__balance

    def __str__(self):
        return self.name

users = []
def createAccount(name,email):
    obj = Bank(name,email)
    users.append(obj)
    return obj

def enquiry(email,pin):
    for i in range(len(users)):
        if users[i].email == email and users[i].getPin() == pin:
            return users[i]
    else:
        return "Invalid Details, User Not Found"